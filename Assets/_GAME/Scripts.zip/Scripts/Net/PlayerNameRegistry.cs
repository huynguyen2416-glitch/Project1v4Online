using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Netcode;
using UnityEngine;

/// <summary>
/// Lưu tên hiển thị (display name) của từng người chơi, đồng bộ mọi máy.
/// Gắn vào cùng GameObject với NetworkManager (không bị hủy khi đổi scene).
///
/// Luồng:
///   1. Lobby/Menu: người dùng nhập tên → PlayerPrefs["playerName"].
///   2. Khi nhân vật spawn (PlayerIdentity.OnNetworkSpawn), chủ nhân gọi RegisterNameServerRpc().
///   3. Server lưu vào NetworkList → mọi máy nhận được ngay (kể cả reconnect).
///   4. MatchStatusHUD.cs đọc qua GetName(clientId) để hiển thị.
///
/// TÊN MẶC ĐỊNH: "Người chơi #<clientId>" nếu chưa đặt hoặc để trống.
/// </summary>
public class PlayerNameRegistry : NetworkBehaviour
{
    public static PlayerNameRegistry Instance { get; private set; }

    public const string PrefKey    = "playerName";
    public const int    MaxLength  = 16;

    // ── NetworkList entry ─────────────────────────────────────────────────────

    public struct NameEntry : INetworkSerializable, IEquatable<NameEntry>
    {
        public ulong         ClientId;
        public FixedString64Bytes Name;   // tối đa 64 byte UTF-8 (~21 ký tự tiếng Việt)

        public void NetworkSerialize<T>(BufferSerializer<T> s) where T : IReaderWriter
        {
            s.SerializeValue(ref ClientId);
            s.SerializeValue(ref Name);
        }

        public bool Equals(NameEntry o) => ClientId == o.ClientId && Name == o.Name;
    }

    NetworkList<NameEntry> entries;

    /// <summary>Bắn khi có tên mới / tên cũ đổi → MatchStatusHUD lắng nghe để vẽ lại.</summary>
    public event Action OnChanged;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(this); return; }
        Instance = this;
        entries  = new NetworkList<NameEntry>();
    }

    public override void OnNetworkSpawn()
    {
        entries.OnListChanged += _ => OnChanged?.Invoke();
    }

    public override void OnNetworkDespawn()
    {
        // entries không cần unsubscribe — NetworkList tự dọn
    }

    // ── API công khai ─────────────────────────────────────────────────────────

    /// <summary>Đọc tên hiển thị của clientId. Không tìm thấy → trả về "Người chơi #id".</summary>
    public string GetName(ulong clientId)
    {
        for (int i = 0; i < entries.Count; i++)
            if (entries[i].ClientId == clientId)
                return entries[i].Name.ToString();
        return "Người chơi #" + clientId;
    }

    /// <summary>Tên của máy local.</summary>
    public string LocalName => GetName(NetworkManager.LocalClientId);

    /// <summary>Lấy tên lưu trong PlayerPrefs, làm sạch và giới hạn độ dài.</summary>
    public static string GetSavedName()
    {
        string n = PlayerPrefs.GetString(PrefKey, "").Trim();
        if (n.Length > MaxLength) n = n.Substring(0, MaxLength);
        return n;
    }

    /// <summary>Lưu tên vào PlayerPrefs (gọi từ UI nhập tên).</summary>
    public static void SaveName(string name)
    {
        name = (name ?? "").Trim();
        if (name.Length > MaxLength) name = name.Substring(0, MaxLength);
        PlayerPrefs.SetString(PrefKey, name);
        PlayerPrefs.Save();
    }

    // ── Chủ nhân nhân vật gọi khi spawn ──────────────────────────────────────

    /// <summary>
    /// Gọi từ PlayerIdentity.OnNetworkSpawn (phía chủ nhân) để đăng ký tên lên server.
    /// </summary>
    [ServerRpc(RequireOwnership = false)]
    public void RegisterNameServerRpc(FixedString64Bytes name, ServerRpcParams p = default)
    {
        ulong id = p.Receive.SenderClientId;

        // Kiểm tra trùng rồi update / thêm mới
        for (int i = 0; i < entries.Count; i++)
        {
            if (entries[i].ClientId != id) continue;
            if (entries[i].Name == name) return;                // không đổi → bỏ qua
            entries[i] = new NameEntry { ClientId = id, Name = name };
            return;
        }
        entries.Add(new NameEntry { ClientId = id, Name = name });
    }

    /// <summary>Server tự gọi khi client disconnect để dọn entry.</summary>
    public void RemoveClient(ulong clientId)
    {
        if (!IsServer) return;
        for (int i = 0; i < entries.Count; i++)
        {
            if (entries[i].ClientId != clientId) continue;
            entries.RemoveAt(i);
            return;
        }
    }
}
