using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// Tìm đường cho bot bằng NavMesh (chỉ TÍNH đường, không dùng NavMeshAgent): nhân vật vẫn đi bằng CharacterController
/// qua NetworkPlayerMovement, nên không có gì phải đồng bộ thêm. Cần bake NavMesh cho map (xem lộ trình C0).
/// Chưa có NavMesh thì tự đi thẳng tới đích (kém thông minh nhưng không lỗi) và ghi cảnh báo 1 lần.
/// Ngoài đường đi còn có: tránh tường (trượt dọc tường thay vì đâm thẳng), gỡ kẹt (bước sang bên rồi tính lại đường),
/// và vẽ đường đi bằng Debug.DrawLine (màu xanh lơ, xem trong Scene view khi đang chạy).
/// </summary>
public class BotNavigator : MonoBehaviour
{
    public enum NavMode { Idle, NavMesh, Direct, Fallback, Unstick }

    [Header("Đường đi")]
    [SerializeField] float cornerReach = 0.7f;
    [SerializeField] float repathInterval = 0.5f;
    [SerializeField] float destinationMoveThreshold = 1.5f;
    [Tooltip("Tìm điểm NavMesh gần chân bot trong bán kính này. Đừng để lớn: quá 2m có thể dính sang phía bên kia tường.")]
    [SerializeField] float sourceSampleRadius = 1.5f;
    [SerializeField] float destSampleRadius = 3f;
    [Tooltip("Còn cách đích dưới ngần này VÀ NavMesh xác nhận không có gì chắn thì đi thẳng (đích thường nằm sát collider nên NavMesh không dẫn tới tận nơi).")]
    [SerializeField] float directRange = 5f;

    [Header("Tránh tường và gỡ kẹt")]
    [SerializeField] float probeDistance = 1.0f;
    [Tooltip("Độ cao (từ chân) của tia dò tường. Thấp hơn ngần này một chút là bậc thềm, không coi là tường.")]
    [SerializeField] float probeHeight = 0.9f;
    [SerializeField] LayerMask obstacleMask = ~0;
    [SerializeField] float stuckSeconds = 0.8f;
    [SerializeField] float unstickSeconds = 0.7f;

    NavMeshPath path;
    Vector3[] corners = new Vector3[0];
    int cornerIndex;
    Vector3 destination;
    Vector3 destOnMesh;
    float stopDistance;
    bool hasDestination;
    bool fallback;
    float nextRepath;

    CharacterController cc;
    Vector3 lastPos;
    Vector3 lastDesired;
    Vector3 unstickDir;
    float stuckTimer;
    float unstickUntil;
    float lastStuckTime = -99f;
    int stuckCount;
    bool stuckFlag;
    bool warned;
    bool settingsChecked;

    public NavMode Mode { get; private set; } = NavMode.Idle;
    public bool HasDestination => hasDestination;
    public Vector3 Destination => destination;

    /// <summary>Đã tới đủ gần đích (trong stopDistance).</summary>
    public bool Arrived => hasDestination && Flat(destination - transform.position).magnitude <= stopDistance;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
    }

    public void SetDestination(Vector3 dest, float stop)
    {
        stopDistance = Mathf.Max(0.1f, stop);
        bool changed = !hasDestination || Flat(dest - destination).magnitude > destinationMoveThreshold;
        destination = dest;
        hasDestination = true;
        if (changed) Repath();
    }

    public void Stop()
    {
        hasDestination = false;
        corners = new Vector3[0];
        Mode = NavMode.Idle;
        ClearStuck();
    }

    /// <summary>true nếu bot kẹt liên tục (đã thử gỡ kẹt mà vẫn không đi được). Brain nên bỏ mục tiêu này. Gọi là xóa cờ.</summary>
    public bool ConsumeStuck()
    {
        bool s = stuckFlag;
        stuckFlag = false;
        return s;
    }

    /// <summary>Gọi mỗi khung hình khi nhân vật được phép đi. Trả về hướng đi trong thế giới (x, z), (0,0) nếu đứng yên.</summary>
    public Vector2 Steer()
    {
        if (!hasDestination) { Mode = NavMode.Idle; ClearStuck(); return Vector2.zero; }

        Vector3 pos = transform.position;
        float distToDest = Flat(destination - pos).magnitude;
        if (distToDest <= stopDistance) { Mode = NavMode.Idle; ClearStuck(); return Vector2.zero; }

        if (Time.time >= nextRepath) Repath();

        // Đang gỡ kẹt: bước sang bên một chút.
        if (Time.time < unstickUntil)
        {
            Mode = NavMode.Unstick;
            lastPos = pos;
            return ToVec2(Avoid(unstickDir));
        }

        TrackStuck(pos);

        Vector3 aim = ChooseAim(pos, distToDest);
        Vector3 d = Flat(aim - pos);
        if (d.sqrMagnitude < 0.0001f) return Vector2.zero;
        d.Normalize();
        lastDesired = d;
        return ToVec2(Avoid(d));
    }

    // ---------- Chọn điểm hướng tới ----------

    Vector3 ChooseAim(Vector3 pos, float distToDest)
    {
        if (fallback || corners.Length == 0)
        {
            Mode = NavMode.Fallback;
            return destination;
        }

        // Gần đích và NavMesh cho thấy không có gì chắn: đi thẳng.
        if (distToDest <= directRange
            && NavMesh.SamplePosition(pos, out NavMeshHit here, 1f, NavMesh.AllAreas)
            && !NavMesh.Raycast(here.position, destOnMesh, out NavMeshHit _, NavMesh.AllAreas))
        {
            Mode = NavMode.Direct;
            return destination;
        }

        Mode = NavMode.NavMesh;
        while (cornerIndex < corners.Length - 1 && Flat(corners[cornerIndex] - pos).magnitude < cornerReach) cornerIndex++;

        Vector3 prev = pos + Vector3.up * 0.2f;
        for (int i = cornerIndex; i < corners.Length; i++)
        {
            Vector3 c = corners[i] + Vector3.up * 0.2f;
            Debug.DrawLine(prev, c, Color.cyan);
            prev = c;
        }
        return corners[cornerIndex];
    }

    // ---------- Tránh tường ----------

    /// <summary>Có tường ngay phía trước thì trượt dọc tường thay vì đâm thẳng vào.</summary>
    Vector3 Avoid(Vector3 dir)
    {
        if (dir.sqrMagnitude < 0.0001f) return dir;

        Vector3 origin = transform.position + Vector3.up * probeHeight;
        float radius = cc != null ? Mathf.Max(0.2f, cc.radius * 0.9f) : 0.3f;
        if (!Physics.SphereCast(origin, radius, dir, out RaycastHit hit, probeDistance, obstacleMask, QueryTriggerInteraction.Ignore))
            return dir;

        if (hit.collider.transform.IsChildOf(transform)) return dir;                          // chính mình
        if (hit.collider.GetComponentInParent<PlayerRoleInfo>() != null) return dir;          // người chơi khác
        if (hasDestination && Flat(hit.point - destination).magnitude < 1.5f) return dir;     // đang tiến vào đích (máy, pallet, cửa sổ...)

        Vector3 slide = Vector3.ProjectOnPlane(dir, hit.normal);
        slide.y = 0f;
        if (slide.magnitude < 0.25f)   // đâm thẳng vào tường: chọn hướng dọc tường nghiêng về phía đích
        {
            slide = Vector3.Cross(Vector3.up, hit.normal);
            if (Vector3.Dot(slide, Flat(destination - transform.position)) < 0f) slide = -slide;
        }
        return slide.normalized;
    }

    // ---------- Gỡ kẹt ----------

    void TrackStuck(Vector3 pos)
    {
        float speed = Flat(pos - lastPos).magnitude / Mathf.Max(0.0001f, Time.deltaTime);
        lastPos = pos;
        if (speed < 0.3f) stuckTimer += Time.deltaTime; else stuckTimer = 0f;
        if (stuckTimer < stuckSeconds) return;

        stuckTimer = 0f;
        if (Time.time - lastStuckTime > 6f) stuckCount = 0;
        lastStuckTime = Time.time;
        stuckCount++;
        if (stuckCount >= 2) { stuckFlag = true; stuckCount = 0; }   // kẹt lần thứ hai trong 6 giây: báo brain bỏ mục tiêu

        float side = Random.value < 0.5f ? -1f : 1f;
        Vector3 basis = lastDesired.sqrMagnitude > 0.01f ? lastDesired : transform.forward;
        unstickDir = Quaternion.Euler(0f, side * 110f, 0f) * basis;   // sang bên và hơi lùi
        unstickDir.y = 0f;
        unstickDir.Normalize();
        unstickUntil = Time.time + unstickSeconds;
        Repath();
    }

    void ClearStuck()
    {
        stuckTimer = 0f;
        lastPos = transform.position;
    }

    // ---------- Tính đường ----------

    void Repath()
    {
        nextRepath = Time.time + repathInterval;
        if (path == null) path = new NavMeshPath();   // không tạo ở field: Unity cấm trong MonoBehaviour
        cornerIndex = 0;
        fallback = false;
        CheckAgentSettings();

        if (!NavMesh.SamplePosition(transform.position, out NavMeshHit from, sourceSampleRadius, NavMesh.AllAreas) ||
            !NavMesh.SamplePosition(destination, out NavMeshHit to, destSampleRadius, NavMesh.AllAreas))
        {
            UseFallback("bot đứng ngoài vùng NavMesh hoặc đích không nằm gần NavMesh");
            return;
        }
        destOnMesh = to.position;

        if (NavMesh.CalculatePath(from.position, to.position, NavMesh.AllAreas, path)
            && path.status != NavMeshPathStatus.PathInvalid && path.corners.Length > 0)
        {
            corners = path.corners;
            cornerIndex = corners.Length > 1 ? 1 : 0;
        }
        else
        {
            UseFallback("không tính được đường");
        }
    }

    void UseFallback(string reason)
    {
        fallback = true;
        corners = new Vector3[0];
        if (warned) return;
        warned = true;
        Debug.LogWarning($"[Bot] {name}: {reason}. Đang đi thẳng tới đích nên dễ kẹt tường. Kiểm tra đã bake NavMesh chưa và bot có đứng trong vùng xanh không.");
    }

    /// <summary>Cảnh báo nếu CharacterController to hơn Agent Radius của NavMesh: đường đi sẽ sát tường hơn thân bot cho phép.</summary>
    void CheckAgentSettings()
    {
        if (settingsChecked) return;
        settingsChecked = true;
        if (cc == null) return;

        NavMeshBuildSettings s = NavMesh.GetSettingsByID(0);
        if (cc.radius > s.agentRadius + 0.05f)
            Debug.LogWarning($"[Bot] CharacterController.radius ({cc.radius:F2}) lớn hơn Agent Radius của NavMesh ({s.agentRadius:F2}) nên bot hay cọ tường. " +
                             "Tăng Agent Radius (Window > AI > Navigation > Agents, loại Humanoid) bằng hoặc lớn hơn CharacterController.radius rồi bake lại.");
    }

    static Vector3 Flat(Vector3 v) { v.y = 0f; return v; }
    static Vector2 ToVec2(Vector3 v) => new Vector2(v.x, v.z);
}